<?php
    $email = $_POST["mail"];
    $password = $_POST["pwd"];
    if(isset($email) && isset($password)){
        require_once __DIR__.'/../Models/Users.php';
        $user = new Users($email,$password);
        $user->setUser('users');
        header('location: ../../template/login.php');
    } else {
        header('location: ../../template/login.php');
    }
?>