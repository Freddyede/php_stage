<?php
    require_once '../Models/Database.php';
    require_once '../Models/Users.php';
    if(Database::findByEmail($_POST["mail"], 'users')){
        if(Users::login($_POST["pwd"],Database::getPassword($_POST["mail"],'users')[0]["passwords"])){
            session_start();
            $_SESSION["users"] = new Users($_POST["mail"],$_POST["pwd"]);
            header('location: ../../template/admin.php');
        } else {
            var_dump('Utilisateur non trouvé');
        }
    } else{
        var_dump('non correspondant');
    }
?>