<?php

class Database  {
    public function selectData($table) {
        $pdo = new PDO('mysql:host=localhost;dbname=exam', 'root', 'root');
        $sql = 'SELECT * FROM '.$table;
        $req = $pdo->prepare($sql);
        $req->execute();
        return $req->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insertUser($mail,$passwords,$table) {
        $pdo = new PDO('mysql:host=localhost;dbname=exam', 'root', 'root');
        $sql = "INSERT INTO $table (mail,passwords) VALUES (:mail,:passwords)";
        $req = $pdo->prepare($sql);
        $req->bindParam(':mail', $mail);
        $req->bindParam(':passwords', $passwords);
        $req->execute();
        return $req->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function findByEmail($email,$table)  {
        $pdo = new PDO('mysql:host=localhost;dbname=exam', 'root', 'root');
        $sql = "SELECT * FROM $table WHERE mail = :email";
        $req = $pdo->prepare($sql);
        $req->bindParam(':email',$email);
        $req->execute();
        if(count($req->fetchAll(PDO::FETCH_ASSOC)) === 1){
            return true;
        } else {
            return false;
        }
    }
    public static function getPassword($email,$table){
        $pdo = new PDO('mysql:host=localhost;dbname=exam', 'root', 'root');
        $sql = "SELECT passwords FROM $table WHERE mail = :email";
        $req = $pdo->prepare($sql);
        $req->bindParam(':email',$email);
        $req->execute();
        return $req->fetchAll(PDO::FETCH_ASSOC);
    }
}